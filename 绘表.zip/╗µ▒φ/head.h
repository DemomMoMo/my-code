#define _CRT_SECURE_NO_WARNINGS 1
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<string.h>

typedef struct infor
{
	char Target;
}infor;


typedef struct list
{
	int x;
	int y;
	int lar;//��ǰ�ַ�����
	int lod; //��ǰָ��λ��
	infor *me;
}list;

int Read(list*ps);
void Target_Well(list*ps);
void Ed(list*ps);
void Out1(list*ps);
void Add(list*ps);
void Show(list*ps);
void Out2(list*ps);
